# Layout

## Spacing
Scale: 6, 16, 24 (dp)

- `dialog_content_padding`: 24dp
- `dialog_content_top_padding`: 6dp
- `list_column_padding`: 16dp
- `title_bottom_padding`: 6dp
- `webapp_splash_large_title_margin_bottom`: 16dp

