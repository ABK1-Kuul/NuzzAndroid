# Licences

- Colour values, spacing, durations and easing are measurements.
- `assets/` and `frames/` hold files copied from Nuzz (images, icons, Lottie, fonts, screen captures), included at the user’s choice.

