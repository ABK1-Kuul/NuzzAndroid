# Nuzz: design rules

A light interface on a off-white background where a off-white accent (#e6e6e6) marks what matters. Type comes from the system font (no bundled typeface was found). Built with Android Views.

## Principles

### One accent: off-white

Use #e6e6e6 for primary actions, the active state and key numbers. Neutrals do the rest.

_Why:_ It is the theme's colorPrimary (source: theme), and it reaches 1.1:1 on the background (Fail).

For small text and links in the accent, use #6c6c6c (4.7:1); keep #e6e6e6 for fills and large text.

### Text on off-white

Body text is #000000 on #f3f3f3 (18.9:1).

## Never

- Never add a second accent colour.
- Never ship text below 4.5:1 contrast.
