# Motion

No animation resources were found: this app animates in code. Use calm defaults (150–300ms, cubic(0.4, 0, 0.2, 1)) and respect reduced motion.
