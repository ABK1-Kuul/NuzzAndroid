# Screens

## Activities in the manifest

- `org.chromium.webapk.shell_apk.h2o.H2OOpaqueMainActivity` (launcher)
- `org.chromium.webapk.shell_apk.h2o.H2OTransparentLauncherActivity`
- `org.chromium.webapk.shell_apk.ManageDataLauncherActivity`
- `org.chromium.webapk.shell_apk.h2o.SplashActivity`
- `org.chromium.webapk.shell_apk.h2o.H2OMainActivity`
- `org.chromium.webapk.shell_apk.NotificationPermissionRequestActivity`
- `android.app.AppDetailsActivity`
