---
name: applivery-nuzz
description: Apply the Nuzz app design kit (Applivery v1) to this project. Use only when the user asks to apply this kit or this app's design.
---

# Nuzz design kit · v1 · flow 1

**Never edit a file before step 5. Ask, don't assume.**

A light interface on a off-white background where a off-white accent (#e6e6e6) marks what matters. Type comes from the system font (no bundled typeface was found). Built with Android Views.

Read from the installed Android app `org.chromium.webapk.ad7623b84882c590a_v2` v1 by Applivery on 2026-10-19.

Kit files (read each one only when its step needs it): `rules.md`, `tokens.json`, `fonts.json`, `motion.md`, `layout.md`, `screens.md`, `licences.md`, `assets.md`, `assets/`.

Levels offered:
1. Tokens: colour roles (light), type, spacing and radii.
2. Assets: the app’s images, icons, Lottie and fonts in `assets/`.

## 0. Prepare
- Require git. If the working tree has uncommitted changes, ask the user to commit or stash first.
- Create and switch to a branch named after this kit.

## 1. Audit
Find theme files, design tokens, colour definitions (CSS variables, Tailwind config, Flutter `ThemeData`, Compose `MaterialTheme`, Android `themes.xml`), fonts, the icon library and how colours are used.
Report colours that are scattered rather than centralised; offer to centralise them first.

## 2. Scan project rules
Read CLAUDE.md, AGENTS.md, .cursor/rules, design docs, lint rules and contrast tests. Sort each finding as hard (must keep), soft (preference) or unrelated.

## 3. Report the gap
For each area (tokens, type, motion, layout, screens), rate the gap small / medium / large against `rules.md` and `tokens.json`.

## 4. Ask
Ask which areas to apply, and what must not change (logo colours, required brand colours, legal copy).

## 5. Resolve conflicts
Quote each conflicting project rule with file:line and offer: keep the rule / override once / override and update the rule.

## 6. Assets
Read `assets.md`. The app's images, icons (rendered vectors), Lottie animations and fonts are in `assets/`: use them directly where the design calls for them.
Register fonts from `assets/fonts/` in the project's font setup. `licences.md` lists what was copied.

## 7. Apply
One area per commit, in this order: tokens → type → layout → motion. Commit message: `applivery(<kit>): <area>`.
Map roles onto the project's own theme system (CSS variables, Tailwind theme, Flutter ThemeExtension, Compose ColorScheme). Follow `rules.md` throughout.

## 8. Verify
Check text contrast in both themes (4.5:1 body, 3:1 large text and UI). If the accent fails on the user's backgrounds, adjust its lightness rather than shipping unreadable text.
If screenshots are possible, compare layout rhythm with `frames/`.

## 9. Keep it
Offer to add the core of `rules.md` to the project's CLAUDE.md (or AGENTS.md) so future sessions keep the design.

## 10. Summary
List what changed per area with its commit hash. To undo one area: `git revert <hash>`.

