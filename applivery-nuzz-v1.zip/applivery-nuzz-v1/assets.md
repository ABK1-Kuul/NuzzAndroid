# Assets

Copied from the installed package of Nuzz (`org.chromium.webapk.ad7623b84882c590a_v2`). Use them directly.

- `assets/images/`: 3 files, bitmaps (PNG, WebP, JPEG, 9-patch), the densest copy of each.
- `assets/vectors/`: 2 files, every drawable defined in XML (icons, shapes), rendered to PNG at up to 3×, and as editable SVG where the drawable could be drawn as one.
